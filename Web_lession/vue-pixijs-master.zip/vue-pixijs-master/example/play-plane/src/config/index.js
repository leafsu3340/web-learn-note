export const stage = {
  width: 750,
  height: 1080,
};


