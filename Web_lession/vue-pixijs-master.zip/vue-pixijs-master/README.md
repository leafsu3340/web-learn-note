# vue-pixijs

使用 vue3 的语法来开发 pixijs 

## 实现原理

实现了自定义的 vue Renderer ，渲染使用 pixijs 


## why

1. 需求驱动学习 vue3 + pixijs
2. 以开发小游戏的形式去完善 Renderer


## 进行中
1. [打飞机游戏](https://github.com/cuixiaorui/vue-pixijs/tree/master/example/play-plane)

